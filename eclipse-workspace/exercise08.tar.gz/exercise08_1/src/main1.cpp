/*
 * main.cpp
 *
 *  Created on: Dec 5, 2011
 *      Author: Benjamin Resch
 */

#include <fstream>
#include <map>
#include <assert.h>

#include "utils/fileio.h"
#include "utils/vec.h"

using namespace std;

map<int, Vec3> loadCMF()
{
	map<int, Vec3> result;

	// TODO 8.1 a) Load the CMF data or hardcode it here.
	// Feel free to modify the return type and parameters if you need.

	return result;
}

int main(int argc, char** argv)
{
	Vec3* result = new Vec3[512 * 256];
	for (unsigned int p = 0; p < 512 * 256; p++)
		result[p] = Vec3(0.0f, 0.0f, 0.0f);

	map<int, Vec3> cmf = loadCMF();

	// TODO 8.1 b) Load all env_roof_l???.pfm images and add the response that is caused by them to the result image.

	// TODO 8.1 c) Save the resulting image.

	delete[] result;
}
